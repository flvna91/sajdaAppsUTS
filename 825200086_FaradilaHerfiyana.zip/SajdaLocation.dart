import 'package:flutter/material.dart';

void main() {
  runApp(MyWidget());
}

class MyWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Container(
          //background
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage("images/bg.jpg"),
              fit: BoxFit.cover,
              colorFilter: ColorFilter.mode(Colors.black45, BlendMode.darken),
            ),
          ),

          //Pilih Lokasi Anda
          child: Column(
            children: <Widget>[
              Container(
                  height: 70,
                  margin: EdgeInsets.fromLTRB(0, 60, 0, 0),
                  //padding: EdgeInsets.fromLTRB(50, 0, 0, 0),
                  child: Column(
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Padding(padding: EdgeInsets.fromLTRB(70, 0, 0, 0)),
                          Text(
                            "Pilih \nlokasi Anda",
                            style: TextStyle(
                                color: Color.fromARGB(175, 255, 255, 255),
                                fontSize: 28),
                          ),
                        ],
                      )
                    ],
                  )),

              //Pencarian
              Container(
                height: 50,
                margin: EdgeInsets.fromLTRB(38, 20, 38, 15),
                child: Column(
                  children: <Widget>[
                    TextField(
                      style: TextStyle(color: Colors.white),
                      decoration: new InputDecoration(
                        enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: Color.fromARGB(150, 255, 255, 255))),
                        prefixIcon: Icon(
                          Icons.search,
                          color: Color.fromARGB(177, 255, 255, 255),
                          size: 20,
                        ),
                        suffixIcon: Icon(
                          Icons.near_me,
                          color: Color.fromARGB(197, 255, 255, 255),
                          size: 15,
                        ),
                        hintText: ("Pencarian"),
                        hintStyle: TextStyle(
                            color: Color.fromARGB(177, 255, 255, 255)),
                      ),
                    ),
                  ],
                ),
              ),

              //Lokasi Terakhir
              Container(
                height: 20,
                margin: EdgeInsets.fromLTRB(0, 0, 0, 15),
                child: Column(
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Padding(padding: EdgeInsets.fromLTRB(77, 0, 0, 0)),
                        Text("Lokasi terakhir",
                            style: TextStyle(
                                color: Color.fromARGB(148, 255, 255, 255),
                                fontSize: 15,
                                fontWeight: FontWeight.bold))
                      ],
                    ),
                  ],
                ),
              ),

              //Block Lokasi Terakhir
              Container(
                height: 65,
                color: Color.fromARGB(192, 5, 5, 5),
                margin: EdgeInsets.fromLTRB(0, 0, 0, 310),
                padding: EdgeInsets.fromLTRB(77, 0, 0, 0),
                child: Row(
                  children: <Widget>[
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          "Pekojan",
                          style: TextStyle(
                              color: Colors.white, fontSize: 16, height: 2.2),
                        ),
                        Text(
                          "Jakarta, Indonesia",
                          style: TextStyle(
                              color: Color.fromARGB(141, 255, 255, 255),
                              fontSize: 14),
                        )
                      ],
                    ),
                  ],
                ),
              ),

              //Button Close
              Container(
                child: Row(
                  children: <Widget>[
                    IconButton(
                        alignment: Alignment.bottomLeft,
                        onPressed: () {},
                        icon: Icon(
                          Icons.cancel_outlined,
                          size: 35,
                          color: Color.fromARGB(177, 255, 255, 255),
                        ))
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
