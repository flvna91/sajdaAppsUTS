import 'package:flutter/material.dart';
import 'package:keepsettings/keepsettings.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Color.fromARGB(255, 223, 223, 223),
        body: ListView(
          //Lokasi
          children: <Widget>[
            Container(
              padding: EdgeInsets.fromLTRB(20, 15, 0, 10),
              child: Row(
                children: <Widget>[
                  Text(
                    "LOKASI",
                    style: TextStyle(
                        color: Color.fromARGB(255, 142, 142, 142),
                        fontSize: 15),
                  )
                ],
              ),
            ),

            //Isi Lokasi
            Card(
              margin: EdgeInsets.all(0),
              child: Row(
                children: <Widget>[
                  Container(
                      height: 30,
                      width: 30,
                      padding: EdgeInsets.fromLTRB(0, 3, 0, 3),
                      margin: EdgeInsets.all(12),
                      color: Colors.blue,
                      child: Icon(
                        Icons.location_on,
                        color: Color.fromARGB(255, 255, 255, 255),
                      )),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "Jakarta",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Text(
                        "Pekojan (Otomatis)",
                        style: TextStyle(
                            color: Color.fromARGB(255, 182, 182, 182)),
                      )
                    ],
                  ),
                  IconButton(
                      padding: EdgeInsets.fromLTRB(200, 0, 0, 0),
                      onPressed: () {},
                      icon: Icon(
                        Icons.more_horiz,
                        size: 20,
                        color: Color.fromARGB(255, 193, 193, 193),
                      )),
                ],
              ),
            ),

            //Pengaturan
            Container(
              padding: EdgeInsets.fromLTRB(20, 15, 0, 5),
              child: Row(
                children: <Widget>[
                  Text(
                    "PENGATURAN",
                    style: TextStyle(
                        color: Color.fromARGB(255, 142, 142, 142),
                        fontSize: 15),
                  )
                ],
              ),
            ),

            //Waktu Sholat
            Card(
              margin: EdgeInsets.all(0),
              child: Row(
                children: <Widget>[
                  Container(
                      height: 30,
                      width: 30,
                      color: Colors.green,
                      margin: EdgeInsets.all(12),
                      child: Icon(
                        Icons.access_time,
                        color: Color.fromARGB(255, 255, 255, 255),
                      )),
                  Row(
                    children: <Widget>[
                      Text(
                        "Waktu Solat",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      IconButton(
                          padding: EdgeInsets.fromLTRB(243, 0, 0, 0),
                          onPressed: () {},
                          icon: Icon(
                            Icons.chevron_right,
                            size: 30,
                            color: Color.fromARGB(255, 193, 193, 193),
                          )),
                    ],
                  ),
                ],
              ),
            ),

            //Pemberitahuan
            Card(
              margin: EdgeInsets.all(0),
              child: Row(
                children: <Widget>[
                  Container(
                      height: 30,
                      width: 30,
                      color: Colors.red,
                      margin: EdgeInsets.all(12),
                      child: Icon(Icons.notifications,
                          color: Color.fromARGB(255, 255, 255, 255))),
                  Row(
                    children: <Widget>[
                      Text(
                        "Pemberitahuan dan Suara",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      IconButton(
                          padding: EdgeInsets.fromLTRB(155, 0, 0, 0),
                          onPressed: () {},
                          icon: Icon(
                            Icons.chevron_right,
                            size: 30,
                            color: Color.fromARGB(255, 193, 193, 193),
                          )),
                    ],
                  ),
                ],
              ),
            ),

            //Bahasa
            Card(
              margin: EdgeInsets.all(0),
              child: Row(
                children: <Widget>[
                  Container(
                      margin: EdgeInsets.all(12),
                      height: 30,
                      width: 30,
                      color: Colors.purple,
                      child: Icon(Icons.language,
                          color: Color.fromARGB(255, 255, 255, 255))),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "Bahasa",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Text(
                        "Bahasa Indonesia",
                        style: TextStyle(
                            color: Color.fromARGB(255, 182, 182, 182)),
                      ),
                    ],
                  ),
                  IconButton(
                      padding: EdgeInsets.fromLTRB(210, 0, 0, 0),
                      onPressed: () {},
                      icon: Icon(
                        Icons.more_horiz,
                        size: 20,
                        color: Color.fromARGB(255, 193, 193, 193),
                      )),
                ],
              ),
            ),

            //Widget
            Card(
              margin: EdgeInsets.fromLTRB(0, 20, 0, 0),
              child: Row(
                children: <Widget>[
                  Container(
                      height: 30,
                      width: 30,
                      margin: EdgeInsets.all(12),
                      child: Icon(Icons.widgets, color: Colors.lightBlue)),
                  Row(
                    children: <Widget>[
                      Text(
                        "Widget",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      IconButton(
                          padding: EdgeInsets.fromLTRB(273, 0, 0, 0),
                          onPressed: () {},
                          icon: Icon(
                            Icons.chevron_right,
                            size: 30,
                            color: Color.fromARGB(255, 193, 193, 193),
                          )),
                    ],
                  ),
                ],
              ),
            ),

            //Lain
            Card(
              margin: EdgeInsets.all(0),
              child: Row(
                children: <Widget>[
                  Container(
                      height: 30,
                      width: 30,
                      margin: EdgeInsets.all(12),
                      child: Icon(Icons.settings, color: Colors.grey)),
                  Row(
                    children: <Widget>[
                      Text(
                        "Lain",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      IconButton(
                          padding: EdgeInsets.fromLTRB(290, 0, 0, 0),
                          onPressed: () {},
                          icon: Icon(
                            Icons.chevron_right,
                            size: 30,
                            color: Color.fromARGB(255, 193, 193, 193),
                          )),
                    ],
                  ),
                ],
              ),
            ),

            //Menyumbang
            Card(
              margin: EdgeInsets.fromLTRB(0, 20, 0, 0),
              child: Row(
                children: <Widget>[
                  Container(
                      height: 30,
                      width: 30,
                      margin: EdgeInsets.all(12),
                      child: Icon(Icons.monitor_heart, color: Colors.pink)),
                  Column(
                    children: <Widget>[
                      Text(
                        "Menyumbang",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                ],
              ),
            ),

            //Tentang Sajda
            Card(
              margin: EdgeInsets.all(0),
              child: Row(
                children: <Widget>[
                  Container(
                      height: 30,
                      width: 30,
                      margin: EdgeInsets.all(12),
                      child: Icon(Icons.shield_moon_sharp)),
                  Row(
                    children: <Widget>[
                      Text(
                        "Tentang Sajda",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      IconButton(
                          padding: EdgeInsets.fromLTRB(225, 0, 0, 0),
                          onPressed: () {},
                          icon: Icon(
                            Icons.chevron_right,
                            size: 30,
                            color: Color.fromARGB(255, 193, 193, 193),
                          )),
                    ],
                  ),
                ],
              ),
            ),

            //Button X
            Container(
              height: 50,
              width: 200,
              color: Color.fromARGB(255, 41, 160, 110),
              margin: EdgeInsets.fromLTRB(0, 56, 0, 0),
              child: Row(
                children: <Widget>[
                  Padding(padding: EdgeInsets.fromLTRB(150, 0, 0, 0)),
                  Text(
                    "PENGATURAN",
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  Padding(padding: EdgeInsets.fromLTRB(105, 0, 0, 0)),
                  IconButton(
                      onPressed: () {},
                      icon: Icon(
                        Icons.cancel_outlined,
                        size: 35,
                        color: Color.fromARGB(175, 255, 255, 255),
                      ))
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
